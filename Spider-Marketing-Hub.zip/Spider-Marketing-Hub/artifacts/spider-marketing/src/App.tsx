import { useEffect, useRef, useState, type FormEvent } from 'react';
import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  CheckCheck,
  Globe2,
  Mail,
  Menu,
  MessageCircle,
  MessageSquareText,
  MousePointer2,
  ShieldCheck,
  Sparkles,
  X,
} from 'lucide-react';
import { FaWhatsapp } from 'react-icons/fa';

const services = [
  {
    number: '01',
    title: 'Bulk email campaigns',
    description: 'Thoughtful email journeys for people who have chosen to hear from your business.',
    icon: Mail,
  },
  {
    number: '02',
    title: 'Data verification',
    description: 'A cleaner, more reliable contact list—with accuracy checks before you reach out.',
    icon: CheckCheck,
  },
  {
    number: '03',
    title: 'SMS campaigns',
    description: 'Short, useful updates and offers delivered to opted-in customers at the right moment.',
    icon: MessageSquareText,
  },
  {
    number: '04',
    title: 'WhatsApp marketing',
    description: 'Helpful conversations, product updates and follow-ups, always with permission.',
    icon: MessageCircle,
  },
  {
    number: '05',
    title: 'Freelance support',
    description: 'An extra pair of hands for research, campaign setup and the everyday digital work.',
    icon: MousePointer2,
  },
  {
    number: '06',
    title: 'Website design',
    description: 'A clear, considered home online that tells customers what you do and what to do next.',
    icon: Globe2,
  },
];

const steps = [
  {
    number: '01 / LISTEN',
    title: 'Pehle aapka business samjhein.',
    body: 'We start with a real conversation about your customers, goals and what is getting in the way.',
  },
  {
    number: '02 / PLAN',
    title: 'Seedha, sensible plan.',
    body: 'Together we pick the right channel and scope. No bloated packages or promised magic numbers.',
  },
  {
    number: '03 / MAKE',
    title: 'Kaam milkar aage badhe.',
    body: 'We set things up with care, keep you in the loop and make space to learn and improve.',
  },
];

function SpiderMark({ roaming = false }: { roaming?: boolean }) {
  return (
    <svg viewBox="0 0 120 140" role="img" aria-label={roaming ? 'Spider mascot moving across the page' : 'Spider Marketing mascot'}>
      <g fill="none" stroke="#28263d" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M43 56 20 39 8 45M38 68 15 66 5 79M40 81 18 94 12 108M48 91 36 114 38 128" />
        <path d="m77 56 23-17 12 6M82 68l23-2 10 13M80 81l22 13 6 14M72 91l12 23-2 14" />
      </g>
      <ellipse cx="60" cy="75" rx="28" ry="33" fill="#f46d48" stroke="#28263d" strokeWidth="5" />
      <ellipse cx="60" cy="43" rx="22" ry="20" fill="#f46d48" stroke="#28263d" strokeWidth="5" />
      <circle cx="52" cy="42" r="4" fill="#28263d" />
      <circle cx="68" cy="42" r="4" fill="#28263d" />
      <path d="M53 51q7 6 14 0" fill="none" stroke="#28263d" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M60 25V8M55 26 45 11M65 26l10-15" stroke="#28263d" strokeWidth="3" strokeLinecap="round" />
      <circle cx="45" cy="10" r="3" fill="#b8e4d5" />
      <circle cx="75" cy="10" r="3" fill="#b8e4d5" />
      {!roaming && <path d="M46 76q14-13 28 0M45 89q15-12 30 0" fill="none" stroke="#28263d" strokeWidth="2" opacity=".32" />}
    </svg>
  );
}

function BrandSpiderMark() {
  return (
    <svg viewBox="0 0 48 48" aria-hidden="true">
      <g fill="none" stroke="#28263d" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
        <path d="M18 17 12 12 7 7M16 22 8 21 3 23M16 27 9 30 4 36M18 31 13 37 11 43" />
        <path d="M30 17 36 12 41 7M32 22 40 21 45 23M32 27 39 30 44 36M30 31 35 37 37 43" />
      </g>
      <g fill="#f46d48" stroke="#28263d" strokeWidth="1.8">
        <circle cx="12" cy="12" r="1.6" /><circle cx="8" cy="22" r="1.6" />
        <circle cx="9" cy="30" r="1.6" /><circle cx="13" cy="37" r="1.6" />
        <circle cx="36" cy="12" r="1.6" /><circle cx="40" cy="22" r="1.6" />
        <circle cx="39" cy="30" r="1.6" /><circle cx="35" cy="37" r="1.6" />
      </g>
      <ellipse cx="24" cy="29" rx="7.2" ry="10.3" fill="#28263d" />
      <ellipse cx="24" cy="29" rx="2.2" ry="6.8" fill="#f46d48" opacity=".88" />
      <ellipse cx="24" cy="16.8" rx="5.8" ry="5.6" fill="#28263d" />
      <circle cx="22" cy="15.8" r="1" fill="#b8e4d5" />
      <circle cx="26" cy="15.8" r="1" fill="#b8e4d5" />
      <path d="m20 21-2 2m10-2 2 2" fill="none" stroke="#28263d" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}

function SpiderWeb({ className = '' }: { className?: string }) {
  return (
    <svg className={`spider-web ${className}`} viewBox="0 0 180 180" aria-hidden="true">
      <path d="M0 0 180 180M0 0 180 90M0 0 90 180M0 0h180M0 0v180" />
      <path d="M0 38c48 0 70 24 71 71M0 75c28 0 34 14 35 35M0 112c12 0 18 6 18 18M38 0c0 48 24 70 71 71M75 0c0 28 14 34 35 35M112 0c0 12 6 18 18 18" />
    </svg>
  );
}

function CursorSpider() {
  const spiderRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handlePointerMove = (event: PointerEvent) => {
      if (event.pointerType !== 'mouse' || !spiderRef.current) return;
      const spider = spiderRef.current;
      spider.style.setProperty('--cursor-x', `${event.clientX + 18}px`);
      spider.style.setProperty('--cursor-y', `${event.clientY + 16}px`);
      spider.dataset.active = 'true';
    };

    const handlePointerLeave = () => {
      if (spiderRef.current) spiderRef.current.dataset.active = 'false';
    };

    window.addEventListener('pointermove', handlePointerMove, { passive: true });
    document.documentElement.addEventListener('pointerleave', handlePointerLeave);
    return () => {
      window.removeEventListener('pointermove', handlePointerMove);
      document.documentElement.removeEventListener('pointerleave', handlePointerLeave);
    };
  }, []);

  return (
    <div className="roaming-spider cursor-spider" ref={spiderRef} aria-hidden="true">
      <span className="roaming-string" />
      <SpiderMark roaming />
    </div>
  );
}

function FloatingWhatsApp() {
  return (
    <a
      href="#contact"
      className="whatsapp-float"
      aria-label="WhatsApp number coming soon. Open the contact form for now."
      title="Number baad mein add hoga — abhi contact form use karein."
    >
      <FaWhatsapp aria-hidden="true" />
      <span className="whatsapp-float-label">
        <strong>WhatsApp</strong>
        <small>Number coming soon</small>
      </span>
    </a>
  );
}

function InquiryForm() {
  const [mailtoHref, setMailtoHref] = useState('');

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const name = String(data.get('name') || '').trim();
    const email = String(data.get('email') || '').trim();
    const phone = String(data.get('phone') || '').trim();
    const service = String(data.get('service') || '').trim();
    const message = String(data.get('message') || '').trim();
    const body = [
      'New website inquiry',
      '',
      `Name: ${name}`,
      `Email: ${email}`,
      `Phone: ${phone}`,
      `Looking for: ${service}`,
      '',
      'Description:',
      message,
    ].join('\n');
    const href = `mailto:abbinfotechsoft@gmail.com?subject=${encodeURIComponent(`Website inquiry: ${service}`)}&body=${encodeURIComponent(body)}`;
    setMailtoHref(href);
    window.location.href = href;
  }

  return (
    <form className="inquiry-card" onSubmit={handleSubmit} data-testid="form-inquiry">
      <h3>Chaliye, baat shuru karein.</h3>
      <p>Details bhariye; email app mein aapka message taiyar ho jayega.</p>
      <label className="field-label" htmlFor="inquiry-name">Your name</label>
      <input id="inquiry-name" name="name" placeholder="What should we call you?" required data-testid="input-name" />
      <label className="field-label" htmlFor="inquiry-email">Email address</label>
      <input id="inquiry-email" type="email" name="email" placeholder="you@example.com" required data-testid="input-email" />
      <label className="field-label" htmlFor="inquiry-phone">Phone number</label>
      <input id="inquiry-phone" type="tel" name="phone" autoComplete="tel" placeholder="+91 98765 43210" required data-testid="input-phone" />
      <label className="field-label" htmlFor="inquiry-service">What are you looking for?</label>
      <select id="inquiry-service" name="service" defaultValue="" required data-testid="select-service">
        <option value="" disabled>Choose a service</option>
        <option>Bulk email campaigns</option>
        <option>Data verification</option>
        <option>SMS campaigns</option>
        <option>WhatsApp marketing</option>
        <option>Freelance support</option>
        <option>Website design</option>
        <option>Not sure yet</option>
      </select>
      <label className="field-label" htmlFor="inquiry-message">Description</label>
      <textarea id="inquiry-message" name="message" placeholder="Tell us a little about what you need." required data-testid="input-message" />
      <button type="submit" className="button-primary" data-testid="button-prepare-message">Send inquiry by email <ArrowRight /></button>
      <p className="form-note">Aapka email app khulega aur details pre-filled hongi. Email bhejne ke liye wahan Send dabayein.</p>
      {mailtoHref && (
        <div className="draft-result" aria-live="polite" data-testid="status-message-ready">
          <p>Your email app should open. If it does not, <a href={mailtoHref}>open the prepared email</a> for <strong>abbinfotechsoft@gmail.com</strong>.</p>
        </div>
      )}
    </form>
  );
}

function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const closeMenu = () => setMenuOpen(false);

  useEffect(() => {
    const webs = Array.from(document.querySelectorAll<SVGSVGElement>('.spider-web'));

    const lightNearbyWebs = (event: PointerEvent) => {
      if (event.pointerType !== 'mouse') return;
      const spiderX = event.clientX + 40;
      const spiderY = event.clientY + 45;

      webs.forEach((web) => {
        const bounds = web.getBoundingClientRect();
        const distanceX = Math.max(bounds.left - spiderX, 0, spiderX - bounds.right);
        const distanceY = Math.max(bounds.top - spiderY, 0, spiderY - bounds.bottom);
        web.dataset.lit = String(Math.hypot(distanceX, distanceY) < 48);
      });
    };

    const dimAllWebs = () => {
      webs.forEach((web) => {
        web.dataset.lit = 'false';
      });
    };

    window.addEventListener('pointermove', lightNearbyWebs, { passive: true });
    document.documentElement.addEventListener('pointerleave', dimAllWebs);
    return () => {
      window.removeEventListener('pointermove', lightNearbyWebs);
      document.documentElement.removeEventListener('pointerleave', dimAllWebs);
    };
  }, []);

  return (
    <main className="site-shell">
      <CursorSpider />
      <FloatingWhatsApp />
      <header className="topbar">
        <div className="container nav-inner">
          <a className="brand" href="#home" aria-label="web-spider home" data-testid="link-home">
            <span className="brand-mark"><BrandSpiderMark /></span>
            <span>web-spider</span>
          </a>
          <nav className={`nav-links${menuOpen ? ' open' : ''}`} aria-label="Main navigation">
            <a href="#services" onClick={closeMenu}>What we do</a>
            <a href="#approach" onClick={closeMenu}>How we work</a>
            <a href="#values" onClick={closeMenu}>Our promise</a>
          </nav>
          <a href="#contact" className="nav-cta" data-testid="link-contact-nav">Let’s talk <ArrowUpRight /></a>
          <button className="menu-toggle" aria-label={menuOpen ? 'Close navigation' : 'Open navigation'} aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)} data-testid="button-menu">
            {menuOpen ? <X /> : <Menu />}
          </button>
        </div>
      </header>

      <section className="container hero" id="home">
        <div className="hero-copy">
          <div className="eyebrow"><span className="eyebrow-dot" /> Independent digital growth studio</div>
          <h1>Reach the right people. <em>Grow</em> your way.</h1>
          <p className="hero-lede">A small, hands-on marketing team for Indian businesses ready to show up better online. Thoughtful campaigns, useful websites, and a real person in your corner.</p>
          <div className="hero-actions">
            <a className="button-primary" href="#contact">Tell us what you need <ArrowRight /></a>
            <a className="text-link" href="#services">Explore services <ArrowDown /></a>
          </div>
          <div className="hero-note">Small team. Straight answers. Work that feels like you.</div>
        </div>
        <div className="hero-art" aria-label="Spider mascot among connected growth channels">
          <SpiderWeb className="web-hero" />
          <div className="orbit" />
          <div className="hero-disc" />
          <svg className="web-lines" viewBox="0 0 500 500" aria-hidden="true">
            <path d="M250 249 80 125M250 249 424 114M250 249 444 335M250 249 93 391M250 249 250 32M250 249 250 473" />
            <path d="M170 111q81-65 162 0t0 138q-81 65-162 0t0-138ZM130 82q121-100 242 0t0 203q-121 100-242 0t0-203Z" />
          </svg>
          <div className="hero-art-card top">
            <div className="mini-label">A better connection</div>
            <div className="mini-row"><span>Right message</span><ArrowUpRight size={14} /></div>
            <div className="mini-bars"><i /><i /><i /><i /><i /></div>
          </div>
          <div className="hero-art-card bottom">
            <div className="mini-label">Your digital web</div>
            <div className="mini-row"><span>Made around you</span><Sparkles size={14} /></div>
            <div className="mini-label" style={{ marginTop: 12 }}>Email · web · messaging</div>
          </div>
          <div className="mascot"><SpiderMark /><div className="mascot-shadow" /></div>
          <div className="float-tag">small team, big heart</div>
        </div>
      </section>

      <section className="services-section" id="services">
        <SpiderWeb className="web-services" />
        <div className="container">
          <div className="services-heading">
            <div>
              <div className="section-kicker">What we can help with</div>
              <h2 className="section-title">Your next step, not a one-size-fits-all package.</h2>
            </div>
            <p className="section-intro">Pick the support you need today. We’ll keep it practical, personal and built around your business.</p>
          </div>
          <div className="service-grid">
            {services.map((service) => {
              const Icon = service.icon;
              return (
                <article className="service-card" key={service.number} data-testid={`card-service-${service.number}`}>
                  <SpiderWeb className="web-card" />
                  <span className="service-number">{service.number} / 06</span>
                  <span className="card-arrow"><ArrowUpRight /></span>
                  <div className="service-icon"><Icon /></div>
                  <h3>{service.title}</h3>
                  <p>{service.description}</p>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      <section className="approach-section" id="approach">
        <SpiderWeb className="web-approach" />
        <div className="container approach-layout">
          <div className="approach-sticky">
            <div className="section-kicker">A simple way forward</div>
            <h2 className="section-title">Good work starts with a good conversation.</h2>
            <p>No jargon, no pressure. Just a small team that listens first, gets to work, and keeps you part of the process.</p>
            <a className="text-link" href="#contact">Start with a conversation <ArrowRight /></a>
          </div>
          <div className="approach-list">
            {steps.map((step) => (
              <article className="approach-item" key={step.number}>
                <SpiderWeb className="web-step" />
                <div className="step">{step.number}</div>
                <div><h3>{step.title}</h3><p>{step.body}</p></div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="ethics-band" id="values">
        <SpiderWeb className="web-ethics" />
        <div className="container ethics-inner">
          <div className="ethics-mark"><ShieldCheck /></div>
          <div className="ethics-copy">
            <h3>Trust is part of the strategy.</h3>
            <p>Campaigns should reach people who have opted in. We respect consent, use contact data responsibly, and never promise guaranteed results.</p>
          </div>
          <span className="ethics-label">Clear. Considered. Consent-first.</span>
        </div>
      </section>

      <section className="contact-section" id="contact">
        <SpiderWeb className="web-contact" />
        <div className="container contact-layout">
          <div className="contact-copy">
            <div className="section-kicker" style={{ color: '#3e3c52' }}>Your business has a next chapter</div>
            <h2 className="contact-title">Let’s make it easier to find you.</h2>
            <p>Tell us where you are and what you’re working towards. We’ll start with a thoughtful conversation—not a pitch deck.</p>
            <div className="contact-detail"><MessageCircle /> Real people, practical ideas, no pressure.</div>
          </div>
          <InquiryForm />
        </div>
      </section>

      <footer className="footer">
        <SpiderWeb className="web-footer" />
        <div className="container footer-inner">
          <a className="brand" href="#home"><span className="brand-mark"><BrandSpiderMark /></span><span>web-spider</span></a>
          <p>📍 Based in India | Serving Worldwide</p>
          <nav className="footer-nav" aria-label="Footer navigation">
            <a href="#services">Services</a><a href="#approach">Approach</a><a href="#contact">Say hello</a>
          </nav>
        </div>
      </footer>
    </main>
  );
}

function App() {
  return <Home />;
}

export default App;
